TRUNCATE mydb.Fornecedor;

TRUNCATE mydb.Departamento;

TRUNCATE mydb.Cargo;

TRUNCATE mydb.Uf;

TRUNCATE mydb.Cidade;

TRUNCATE mydb.Bairro;

TRUNCATE mydb.TipoLogradouro;

TRUNCATE mydb.Logradouro;

TRUNCATE mydb.Endereco;

TRUNCATE mydb.Buraco;

TRUNCATE mydb.Naturalidade;

TRUNCATE mydb.TipoDano;

TRUNCATE mydb.Dano;

TRUNCATE mydb.Cidadao;

TRUNCATE mydb.TipoTelefone;

TRUNCATE mydb.Telefone;

TRUNCATE mydb.EquipeReparo;

TRUNCATE mydb.TipoMaterialEnchimento;

TRUNCATE mydb.MaterialEnchimento;

TRUNCATE mydb.OrdemTrabalho;

TRUNCATE mydb.Funcionario;

TRUNCATE mydb.TipoEquipamento;

TRUNCATE mydb.Equipamento;

TRUNCATE mydb.TipoIndenizacao;

TRUNCATE mydb.Indenizacao;

TRUNCATE mydb.Cidadao_has_Telefone;

TRUNCATE mydb.MaterialEnchimento_has_Fornecedor;

TRUNCATE mydb.Equipamento_has_Fornecedor;