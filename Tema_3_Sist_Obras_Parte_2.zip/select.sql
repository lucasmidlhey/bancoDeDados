SELECT * FROM mydb.Fornecedor;

SELECT * FROM mydb.Departamento;

SELECT * FROM mydb.Cargo;

SELECT * FROM mydb.Uf;

SELECT * FROM mydb.Cidade;

SELECT * FROM mydb.Bairro;

SELECT * FROM mydb.TipoLogradouro;

SELECT * FROM mydb.Logradouro;

SELECT * FROM mydb.Endereco;

SELECT * FROM mydb.Buraco;

SELECT * FROM mydb.Naturalidade;

SELECT * FROM mydb.TipoDano;

SELECT * FROM mydb.Dano;

SELECT * FROM mydb.Cidadao;

SELECT * FROM mydb.TipoTelefone;

SELECT * FROM mydb.Telefone;

SELECT * FROM mydb.EquipeReparo;

SELECT * FROM mydb.TipoMaterialEnchimento;

SELECT * FROM mydb.MaterialEnchimento;

SELECT * FROM mydb.OrdemTrabalho;

SELECT * FROM mydb.Funcionario;

SELECT * FROM mydb.TipoEquipamento;

SELECT * FROM mydb.Equipamento;

SELECT * FROM mydb.TipoIndenizacao;

SELECT * FROM mydb.Indenizacao;

SELECT * FROM mydb.Cidadao_has_Telefone;

SELECT * FROM mydb.MaterialEnchimento_has_Fornecedor;

SELECT * FROM mydb.Equipamento_has_Fornecedor;